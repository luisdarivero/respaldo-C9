DeepLingo 
===============================

Included in this release:

   * Lexical analysis
    
To build, at the terminal type:

    make
   
To run, type:

    ./DeepLingo.exe <file_name>
    
Where <file_name> is the name of a DeepLingo source file. 
