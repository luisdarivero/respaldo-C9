using System;

public class Repeat10Times {
    public static void Main() {
        for (int i = 0; i < 10; i++) {
             Console.Write(i);
             Console.WriteLine(" Hello");
        }
    }
}

