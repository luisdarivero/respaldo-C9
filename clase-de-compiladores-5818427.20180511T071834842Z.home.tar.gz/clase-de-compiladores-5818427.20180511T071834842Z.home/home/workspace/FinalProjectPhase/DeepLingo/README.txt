
Included in this release:

    * Lexical analysis
    * Syntactic analysis
    * AST construction
    
To build, at the terminal type:

    make
   
To run, type:

    ./deepLingo.exe <file_name>
