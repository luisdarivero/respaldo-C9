
INT64 PROGRAMMING LANGUAGE COMPILER

Copyright (C) 2017 Andrea Iram Molina O & Diego Trujillo N under WTFPL.


To compile:
    $ make

To run:
    $ mono RunTest.exe
    
