
var = 57%31



puts (var)