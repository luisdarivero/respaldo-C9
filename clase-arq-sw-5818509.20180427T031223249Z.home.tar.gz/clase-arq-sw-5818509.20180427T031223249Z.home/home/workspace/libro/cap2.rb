puts ("hello world\n\n"); #comentatrio
x = 10 + 10 +
    10
puts (x)
puts(1==1 && true)

if 1<0
    puts("hola")
else
    puts("adios")
end

puts("woow") if 1==1

unless 20<1 #si es falso, lo imprime
    puts("wowx2")
end

